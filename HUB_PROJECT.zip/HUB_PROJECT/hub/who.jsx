import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { 
  faCode,
  faMicrochip,
  faPaintbrush,
  faChartLine,
  faRocket,
  faGears
} from '@fortawesome/free-solid-svg-icons'

export default function Who() {
  const talents = [
    {
      icon: faCode,
      title: "Software Developers",
      description: "Backend, frontend, mobile, and full-stack developers building innovative applications and solutions."
    },
    {
      icon: faMicrochip,
      title: "Hardware Engineers",
      description: "Electrical, electronic, and robotics engineers creating tangible solutions to real-world problems."
    },
    {
      icon: faPaintbrush,
      title: "Designers",
      description: "UI/UX, graphic, and product designers crafting beautiful, functional, and user-centered experiences."
    },
    {
      icon: faChartLine,
      title: "Data Scientists",
      description: "Analysts, ML engineers, and AI specialists turning data into insights and intelligent systems."
    },
    {
      icon: faRocket,
      title: "Entrepreneurs",
      description: "Tech founders and innovators building startups and solutions to address local and global challenges."
    },
    {
      icon: faGears,
      title: "Mechatronics Engineers",
      description: "Multidisciplinary engineers combining mechanical, electrical, and computing skills to build automated systems."
    }
  ]

  return (
    <section id="who" className="py-12 md:py-20 bg-softgray">
      <div className="container mx-auto px-4">
        <h2 className="font-montserrat font-bold text-3xl md:text-4xl text-center mb-8 md:mb-16">
          Who Should Be in This?
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {talents.map((talent, index) => (
            <div 
              key={index} 
              className={`bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 animate-scale-in ${index > 0 ? `delay-${index * 100}` : ''}`}
            >
              <div className="text-gold text-3xl mb-4">
                <FontAwesomeIcon icon={talent.icon} />
              </div>
              <h3 className="font-montserrat font-semibold text-xl mb-3">{talent.title}</h3>
              <p className="text-gray-600">{talent.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}