import { useState } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { 
  faEye, 
  faPeopleGroup, 
  faDoorOpen, 
  faLightbulb 
} from '@fortawesome/free-solid-svg-icons'

export default function Why() {
  const [currentSlide, setCurrentSlide] = useState(0)
  
  const reasons = [
    {
      icon: faEye,
      title: "Visibility",
      description: "Many talented Nigerian students remain invisible to employers and opportunities simply because they lack platforms to showcase their work and skills."
    },
    {
      icon: faPeopleGroup,
      title: "Community",
      description: "Connecting with like-minded peers across institutions creates a powerful network of support, collaboration, and shared growth opportunities."
    },
    {
      icon: faDoorOpen,
      title: "Opportunity",
      description: "By showcasing talent in a centralized directory, we create pathways to internships, jobs, mentorship, and funding for deserving students."
    },
    {
      icon: faLightbulb,
      title: "Innovation",
      description: "By highlighting diverse talents and projects, we inspire a new generation of problem-solvers addressing Nigeria's unique challenges."
    }
  ]

  return (
    <section id="why" className="py-12 md:py-20 bg-navy text-white">
      <div className="container mx-auto px-4">
        <h2 className="font-montserrat font-bold text-3xl md:text-4xl mb-6 animate-slide-left">
          Too many brilliant students stay unseen. We're changing that.
        </h2>
        <div className="mt-8 md:mt-16 relative">
          <div className="slider-container overflow-x-auto pb-8 hide-scrollbar">
            <div 
              className="flex space-x-6 w-max" 
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
              {reasons.map((reason, index) => (
                <div key={index} className="bg-white/10 backdrop-blur-sm rounded-lg p-6 md:p-8 w-80 md:w-96 flex-shrink-0">
                  <div className="text-gold text-3xl mb-4">
                    <FontAwesomeIcon icon={reason.icon} />
                  </div>
                  <h3 className="font-montserrat font-semibold text-xl mb-4">{reason.title}</h3>
                  <p className="text-white/80">{reason.description}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="flex justify-center space-x-2 mt-6">
            {reasons.map((_, index) => (
              <button 
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-3 h-3 rounded-full ${index === currentSlide ? 'bg-white/80' : 'bg-white/40'}`}
              ></button>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}