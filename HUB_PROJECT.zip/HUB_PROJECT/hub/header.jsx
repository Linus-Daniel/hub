import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faBars } from '@fortawesome/free-solid-svg-icons'
import Link from 'next/link'

export default function Header() {
  return (
    <nav id="header" className="fixed w-full bg-white z-50 shadow-sm">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <h1 className="font-montserrat font-bold text-xl mr-8">
            CONCES
          </h1>
          <div className="hidden md:flex space-x-6">
            <span className="text-navy hover:text-gold transition-colors duration-300 cursor-pointer">About</span>
            <span className="text-navy hover:text-gold transition-colors duration-300 cursor-pointer">Why</span>
            <span className="text-navy hover:text-gold transition-colors duration-300 cursor-pointer">Who</span>
            <span className="text-navy hover:text-gold transition-colors duration-300 cursor-pointer">Benefits</span>
            <span className="text-navy hover:text-gold transition-colors duration-300 cursor-pointer">Join Us</span>
          </div>
        </div>
        <div>
          <Link href="/auth" className="bg-gold text-navy px-4 py-2 rounded-lg hover:bg-yellow-500 transition-colors duration-300 font-medium">
            Join the Directory
          </Link>
          <button className="md:hidden ml-4">
            <FontAwesomeIcon icon={faBars} className="text-navy text-xl" />
          </button>
        </div>
      </div>
    </nav>
  )
}