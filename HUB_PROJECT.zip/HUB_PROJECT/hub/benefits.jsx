import { useState } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { 
  faBriefcase,
  faNetworkWired,
  faAward,
  faHandsHolding,
  faHandshake
} from '@fortawesome/free-solid-svg-icons'

export default function Benefits() {
  const [currentSlide, setCurrentSlide] = useState(0)
  
  const benefits = [
    {
      icon: faBriefcase,
      title: "Career Opportunities",
      description: "Get discovered by top employers looking specifically for talent from Christian institutions."
    },
    {
      icon: faNetworkWired,
      title: "Networking",
      description: "Connect with peers, mentors, and industry professionals who share your values and vision."
    },
    {
      icon: faAward,
      title: "Recognition",
      description: "Gain visibility for your skills, projects, and achievements on a respected national platform."
    },
    {
      icon: faHandsHolding,
      title: "Mentorship",
      description: "Access guidance and support from experienced professionals who want to help you grow."
    },
    {
      icon: faHandshake,
      title: "Partnerships",
      description: "Find collaborators for projects, startups, and initiatives aligned with your interests."
    }
  ]

  // Group benefits into slides for carousel
  const slides = []
  for (let i = 0; i < benefits.length; i += 3) {
    slides.push(benefits.slice(i, i + 3))
  }

  return (
    <section id="benefits" className="py-12 md:py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="font-montserrat font-bold text-3xl md:text-4xl text-center mb-8 md:mb-16">
          Benefits of Being Listed
        </h2>
        <div className="relative">
          <div className="benefits-carousel overflow-hidden">
            <div 
              className="flex transition-transform duration-500"
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
              {slides.map((slide, slideIndex) => (
                <div key={slideIndex} className="w-full flex-shrink-0">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 px-2">
                    {slide.map((benefit, index) => (
                      <div key={index} className="bg-softgray rounded-lg p-6 h-full">
                        <div className="text-gold text-3xl mb-4">
                          <FontAwesomeIcon icon={benefit.icon} />
                        </div>
                        <h3 className="font-montserrat font-semibold text-xl mb-3">{benefit.title}</h3>
                        <p className="text-gray-600">{benefit.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="flex justify-center space-x-2 mt-6">
            {slides.map((_, index) => (
              <button 
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-3 h-3 rounded-full ${index === currentSlide ? 'bg-navy' : 'bg-navy/40'}`}
              ></button>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}