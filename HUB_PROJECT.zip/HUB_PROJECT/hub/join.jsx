import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { 
  faUserCheck,
  faFolderOpen,
  faUserPlus
} from '@fortawesome/free-solid-svg-icons'

export default function Join() {
  const actions = [
    {
      icon: faUserCheck,
      title: "Confirm Your Profile",
      description: "Already nominated? Verify your details and complete your profile to go live in the directory.",
      buttonText: "Confirm Now"
    },
    {
      icon: faFolderOpen,
      title: "Submit Your Portfolio",
      description: "Showcase your work, projects, and skills to be considered for inclusion in the directory.",
      buttonText: "Submit Portfolio"
    },
    {
      icon: faUserPlus,
      title: "Nominate Someone",
      description: "Know a talented student who should be featured? Nominate them for consideration.",
      buttonText: "Nominate Now"
    }
  ]

  return (
    <section id="join" className="py-12 md:py-20 bg-navy text-white">
      <div className="container mx-auto px-4">
        <h2 className="font-montserrat font-bold text-3xl md:text-4xl text-center mb-8 md:mb-16">
          How to Get Featured
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
          {actions.map((action, index) => (
            <div 
              key={index} 
              className="bg-white/10 backdrop-blur-sm rounded-lg p-6 md:p-8 hover:bg-white/20 transition-all duration-300 cursor-pointer group"
            >
              <div className="text-gold text-4xl mb-6 group-hover:scale-110 transition-transform duration-300">
                <FontAwesomeIcon icon={action.icon} />
              </div>
              <h3 className="font-montserrat font-semibold text-xl mb-4">{action.title}</h3>
              <p className="text-white/80 mb-6">{action.description}</p>
              <button className="bg-gold text-navy px-4 py-2 rounded-lg font-medium hover:bg-yellow-500 transition-colors duration-300 w-full">
                {action.buttonText}
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}