import Head from 'next/head'
import Header from '../components/Header'
import Hero from '../components/Hero'
import Intro from '../components/Intro'
import About from '../components/About'
import Why from '../components/Why'
import Who from '../components/Who'
import Benefits from '../components/Benefits'
import ProfilePreview from '../components/ProfilePreview'
import Join from '../components/Join'
import Footer from '../components/Footer'
import StickyCTA from '../components/StickyCTA'

export default function Home() {
  return (
    <>
      <Head>
        <title>CONCES National Talent Directory</title>
        <meta name="description" content="A national showcase of Nigeria's brightest engineering, tech, and design talents" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      </Head>

      <Header />
      <main>
        <Hero />
        <Intro />
        <About />
        <Why />
        <Who />
        <Benefits />
        <ProfilePreview />
        <Join />
      </main>
      <Footer />
      <StickyCTA />
    </>
  )
}