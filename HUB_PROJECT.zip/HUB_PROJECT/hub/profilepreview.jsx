import { useState } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { 
  faGraduationCap,
  faLocationDot,
  faCodeBranch,
  faGithub,
  faGlobe,
  faLinkedin,
  faBehance
} from '@fortawesome/free-solid-svg-icons'
import { faGithub as fabGithub, faLinkedin as fabLinkedin, faBehance as fabBehance } from '@fortawesome/free-brands-svg-icons'

export default function ProfilePreview() {
  const [isFlipped, setIsFlipped] = useState(false)

  return (
    <section id="profile-preview" className="py-12 md:py-20 bg-softgray">
      <div className="container mx-auto px-4">
        <h2 className="font-montserrat font-bold text-3xl md:text-4xl text-center mb-8 md:mb-16">
          Profile Card Preview
        </h2>
        <div className="max-w-md mx-auto">
          <div 
            id="profile-card" 
            className="bg-white rounded-lg shadow-lg overflow-hidden h-96 md:h-[450px] group perspective cursor-pointer"
            onClick={() => setIsFlipped(!isFlipped)}
          >
            <div className={`relative w-full h-full transition-transform duration-700 transform-style preserve-3d ${isFlipped ? 'rotate-y-180' : ''}`}>
              {/* Front side */}
              <div className="absolute inset-0 backface-hidden p-6">
                <div className="flex items-center mb-6">
                  <div className="w-16 h-16 rounded-full overflow-hidden mr-4">
                    <img src="/images/profile-avatar.jpg" alt="Profile" className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h3 className="font-montserrat font-semibold text-xl">Amina Okafor</h3>
                    <p className="text-gray-600">Software Engineer</p>
                  </div>
                </div>
                <div className="mb-6">
                  <div className="flex items-center mb-2">
                    <FontAwesomeIcon icon={faGraduationCap} className="text-gold mr-2" />
                    <p>Covenant University, 300 Level</p>
                  </div>
                  <div className="flex items-center mb-2">
                    <FontAwesomeIcon icon={faLocationDot} className="text-gold mr-2" />
                    <p>Lagos, Nigeria</p>
                  </div>
                  <div className="flex items-center">
                    <FontAwesomeIcon icon={faCodeBranch} className="text-gold mr-2" />
                    <p>Full Stack Development, AI/ML</p>
                  </div>
                </div>
                <div className="mb-6">
                  <h4 className="font-montserrat font-medium text-lg mb-2">About</h4>
                  <p className="text-gray-600">
                    Passionate about creating technology solutions that address real problems in Nigeria. Currently working on an AI-powered agricultural monitoring system.
                  </p>
                </div>
                <p className="text-sm text-gray-500 text-center italic">Click to see portfolio links</p>
              </div>
              
              {/* Back side */}
              <div className="absolute inset-0 backface-hidden rotate-y-180 p-6">
                <h4 className="font-montserrat font-medium text-lg mb-4">Portfolio & Links</h4>
                <div className="space-y-3 mb-6">
                  <span className="flex items-center text-navy hover:text-gold transition-colors cursor-pointer">
                    <FontAwesomeIcon icon={fabGithub} className="text-gold mr-2" />
                    <span>github.com/aminadev</span>
                  </span>
                  <span className="flex items-center text-navy hover:text-gold transition-colors cursor-pointer">
                    <FontAwesomeIcon icon={faGlobe} className="text-gold mr-2" />
                    <span>aminaokafor.dev</span>
                  </span>
                  <span className="flex items-center text-navy hover:text-gold transition-colors cursor-pointer">
                    <FontAwesomeIcon icon={fabLinkedin} className="text-gold mr-2" />
                    <span>linkedin.com/in/aminaokafor</span>
                  </span>
                  <span className="flex items-center text-navy hover:text-gold transition-colors cursor-pointer">
                    <FontAwesomeIcon icon={fabBehance} className="text-gold mr-2" />
                    <span>behance.net/aminadesigns</span>
                  </span>
                </div>
                <div className="bg-softgray p-4 rounded-lg">
                  <h4 className="font-montserrat font-medium text-lg mb-2">Scripture Inspiration</h4>
                  <p className="text-gray-600 italic mb-2">
                    "Whatever you do, work at it with all your heart, as working for the Lord, not for human masters."
                  </p>
                  <p className="text-right text-sm">- Colossians 3:23</p>
                </div>
                <p className="text-sm text-gray-500 text-center italic mt-4">Click to see basic info</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}