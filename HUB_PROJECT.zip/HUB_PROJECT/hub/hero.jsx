import { useState, useEffect } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faChevronDown } from '@fortawesome/free-solid-svg-icons'

export default function Hero() {
  const [scrollPosition, setScrollPosition] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      setScrollPosition(window.scrollY)
    }
    
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <section id="hero" className="relative h-screen flex items-center overflow-hidden">
      <div className="absolute inset-0 bg-navy/60 z-10"></div>
      <div className="absolute inset-0 z-0">
        <img 
          className="w-full h-full object-cover" 
          src="/images/hero-bg.jpg" 
          alt="Nigerian students working on tech and design projects in a modern university setting, diverse group, collaborative environment" 
        />
      </div>
      <div className="container mx-auto px-4 relative z-20">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="font-montserrat font-bold text-4xl md:text-5xl lg:text-6xl text-white mb-4 animate-fade-in">
            The CONCES National Talent Directory
          </h1>
          <p className="text-xl text-white/90 mb-8 animate-slide-up">
            A national showcase of Nigeria's brightest engineering, tech, and design talents
          </p>
          <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4 justify-center">
            <button id="join-btn" className="bg-gold text-navy px-8 py-4 rounded-lg font-montserrat font-semibold text-lg hover:bg-yellow-500 transition-all duration-300 transform hover:scale-105 group relative overflow-hidden">
              <span className="relative z-10">Join the Directory</span>
              <span className="absolute inset-0 bg-white/20 transform scale-0 rounded-full group-hover:scale-150 transition-transform duration-500"></span>
            </button>
            <button id="explore-btn" className="bg-white/10 backdrop-blur-sm text-white border border-white/30 px-8 py-4 rounded-lg font-montserrat font-semibold text-lg hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
              Explore Talents
            </button>
          </div>
        </div>
      </div>
      <div className={`absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white animate-bounce transition-opacity duration-300 ${scrollPosition > 100 ? 'opacity-0' : 'opacity-100'}`}>
        <FontAwesomeIcon icon={faChevronDown} className="text-2xl" />
      </div>
    </section>
  )
}