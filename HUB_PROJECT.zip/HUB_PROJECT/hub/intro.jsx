import { useState, useEffect } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faPlay } from '@fortawesome/free-solid-svg-icons'

export default function Intro() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const slides = [
    "/images/intro-1.jpg",
    "/images/intro-2.jpg",
    "/images/intro-3.jpg",
    "/images/intro-4.jpg"
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 4000)
    return () => clearInterval(interval)
  }, [slides.length])

  return (
    <section id="intro" className="py-12 md:py-20 bg-softgray">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="w-full md:w-1/2 mb-10 md:mb-0 md:pr-10">
            <h2 className="font-montserrat font-bold text-3xl md:text-4xl mb-6 animate-slide-left">
              Meet Nigeria's Next 1,000 Builders
            </h2>
            <div className="space-y-4">
              <p className="text-lg">
                From the bustling labs of Lagos to the innovative hubs of Abuja, Christian students across Nigeria are creating the future.
              </p>
              <p className="text-lg">
                The CONCES National Talent Directory is the first comprehensive showcase of emerging tech, engineering and design talent from Christian higher institutions across Nigeria.
              </p>
              <p className="text-lg">
                Our mission: connect brilliant minds with opportunities that matter.
              </p>
            </div>
            <button id="story-btn" className="mt-8 flex items-center space-x-2 bg-navy text-white px-6 py-3 rounded-lg hover:bg-navy/80 transition-colors duration-300">
              <FontAwesomeIcon icon={faPlay} />
              <span>Our Story</span>
            </button>
          </div>
          <div className="w-full md:w-1/2 relative h-64 md:h-96 rounded-lg overflow-hidden">
            <div id="slideshow" className="relative w-full h-full">
              {slides.map((slide, index) => (
                <div 
                  key={index}
                  className={`absolute inset-0 transition-opacity duration-1000 ${index === currentSlide ? 'opacity-100' : 'opacity-0'}`}
                >
                  <img 
                    className="w-full h-full object-cover rounded-lg" 
                    src={slide} 
                    alt={`Slide ${index + 1}`} 
                  />
                </div>
              ))}
            </div>
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
              {slides.map((_, index) => (
                <button 
                  key={index}
                  onClick={() => setCurrentSlide(index)}
                  className={`w-3 h-3 rounded-full slideshow-dot ${index === currentSlide ? 'bg-white/80' : 'bg-white/40'}`}
                ></button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}