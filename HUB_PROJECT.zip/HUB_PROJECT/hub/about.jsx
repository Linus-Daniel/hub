import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faGlobe, faUsers, faBridge } from '@fortawesome/free-solid-svg-icons'

export default function About() {
  const aboutCards = [
    {
      icon: faGlobe,
      title: "A National Platform",
      description: "The first nationwide directory showcasing the best engineering, tech and design talent from Christian higher institutions across Nigeria."
    },
    {
      icon: faUsers,
      title: "A Community",
      description: "A vibrant network of like-minded students and graduates who share a passion for excellence, innovation, and faith-driven purpose."
    },
    {
      icon: faBridge,
      title: "A Bridge",
      description: "Connecting talented students with companies, mentors, and opportunities that align with their skills, values, and aspirations."
    }
  ]

  return (
    <section id="about" className="py-12 md:py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="font-montserrat font-bold text-3xl md:text-4xl text-center mb-8 md:mb-16">
          What Is This?
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {aboutCards.map((card, index) => (
            <div key={index} className="flip-card bg-white rounded-lg shadow-lg h-64 md:h-80 group perspective">
              <div className="relative w-full h-full transition-transform duration-700 transform-style preserve-3d group-hover:rotate-y-180">
                <div className="absolute inset-0 backface-hidden p-6 flex flex-col items-center justify-center text-center">
                  <div className="text-gold text-4xl mb-4">
                    <FontAwesomeIcon icon={card.icon} />
                  </div>
                  <h3 className="font-montserrat font-semibold text-xl mb-2">{card.title}</h3>
                  <p className="text-gray-600">Flip to learn more</p>
                </div>
                <div className="absolute inset-0 backface-hidden rotate-y-180 bg-navy text-white p-6 flex flex-col items-center justify-center text-center rounded-lg">
                  <p>{card.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}